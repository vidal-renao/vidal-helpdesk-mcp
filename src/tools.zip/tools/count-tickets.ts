// src/tools/count-tickets.ts
// Cuenta tickets totales o agrupados con filtro temporal (v1.2.0)

import { z } from "zod";
import { createClient } from "@supabase/supabase-js";

// ─── Schema ──────────────────────────────────────────────────────────────────

export const countTicketsSchema = z.object({
  group_by: z
    .enum(["status", "priority", "category", "none"])
    .default("none")
    .describe("Agrupar conteo por campo (none = total global)"),
  status: z
    .enum(["open", "in_progress", "pending", "resolved", "closed"])
    .optional()
    .describe("Pre-filtrar por estado antes de contar"),
  since_days: z
    .number()
    .int()
    .min(1)
    .max(365)
    .optional()
    .describe("Contar sólo tickets creados en los últimos N días"),
});

export type CountTicketsInput = z.infer<typeof countTicketsSchema>;

// ─── Supabase client ─────────────────────────────────────────────────────────

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  {
    auth: { persistSession: false, autoRefreshToken: false },
    db: { schema: "public" },
  }
);

// ─── Handler ─────────────────────────────────────────────────────────────────

export async function countTickets(input: CountTicketsInput): Promise<string> {
  const { group_by, status, since_days } = input;

  const sinceIso = since_days
    ? new Date(Date.now() - since_days * 24 * 60 * 60 * 1000).toISOString()
    : null;

  // ── Caso 1: total global (opcionalmente filtrado) ──
  if (group_by === "none") {
    let query = supabase
      .from("tickets")
      .select("*", { count: "exact", head: true });

    if (status) query = query.eq("status", status);
    if (sinceIso) query = query.gte("created_at", sinceIso);

    const { count, error } = await query;

    if (error) {
      return JSON.stringify(
        { error: true, message: `Supabase count failed: ${error.message}` },
        null,
        2
      );
    }

    return JSON.stringify(
      {
        total: count ?? 0,
        filters: { status, since_days },
      },
      null,
      2
    );
  }

  // ── Caso 2: conteo agrupado (agregación en memoria) ──
  // Nota: para volúmenes > ~10k filas, migrar a RPC SQL con GROUP BY.
  let query = supabase.from("tickets").select(group_by);
  if (status) query = query.eq("status", status);
  if (sinceIso) query = query.gte("created_at", sinceIso);

  const { data, error } = await query;

  if (error) {
    return JSON.stringify(
      { error: true, message: `Supabase group query failed: ${error.message}` },
      null,
      2
    );
  }

  const buckets: Record<string, number> = {};
  for (const row of data ?? []) {
    const key = (row as Record<string, unknown>)[group_by] as string | null;
    const bucket = key ?? "(null)";
    buckets[bucket] = (buckets[bucket] ?? 0) + 1;
  }

  return JSON.stringify(
    {
      group_by,
      total: data?.length ?? 0,
      buckets,
      filters: { status, since_days },
    },
    null,
    2
  );
}
