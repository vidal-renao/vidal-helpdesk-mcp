﻿import { z } from "zod";
import { supabase } from "../lib/supabase.js";

export const generateReportSchema = z.object({
  days: z.number().default(7).describe("Días de histórico para el reporte")
});

export async function generateReport(args: { days: number }) {
  try {
    const dateLimit = new Date();
    dateLimit.setDate(dateLimit.getDate() - (args.days || 7));

    const { data, error } = await supabase
      .from("tickets")
      .select("status, priority, category")
      .gte("created_at", dateLimit.toISOString());

    if (error) throw error;
    if (!data || data.length === 0) return `📊 No hay datos para los últimos ${args.days} días.`;

    const total = data.length;
    const byPriority = data.reduce((acc: any, t) => { acc[t.priority] = (acc[t.priority] || 0) + 1; return acc; }, {});
    const byStatus = data.reduce((acc: any, t) => { acc[t.status] = (acc[t.status] || 0) + 1; return acc; }, {});

    return `📈 **Vidal Ecosystem - Infrastructure Report**
- Total Tickets: ${total}
- Priorities: ${JSON.stringify(byPriority)}
- Status: ${JSON.stringify(byStatus)}
- Health: ${total > 5 ? "⚠️ High Load" : "✅ Operational"}`;
  } catch (e: any) {
    return `❌ Error en reporte: ${e.message}`;
  }
}