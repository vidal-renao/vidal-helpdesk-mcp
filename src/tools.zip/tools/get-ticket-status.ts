﻿import { z } from "zod";
import { supabase } from "../lib/supabase.js";

export const getTicketStatusSchema = z.object({
  id: z.string().uuid().describe("ID del ticket en formato UUID")
});

export async function getTicketStatus(args: { id: string }) {
  const { data: ticket, error } = await supabase
    .from('tickets')
    .select('*')
    .eq('id', args.id)
    .single();

  if (error || !ticket) return "❌ Ticket no encontrado en el ecosistema.";

  const deadline = new Date(ticket.sla_deadline);
  const now = new Date();
  const diffMs = deadline.getTime() - now.getTime();
  
  const diffHours = Math.floor(Math.abs(diffMs) / (1000 * 60 * 60));
  const diffMins = Math.floor((Math.abs(diffMs) % (1000 * 60 * 60)) / (1000 * 60));

  const isBreached = diffMs < 0;
  const slaStatus = isBreached 
    ? `🚨 BREACHED (Venció hace ${diffHours}h ${diffMins}m)`
    : `⏳ Tiempo restante: ${diffHours}h ${diffMins}m`;

  return `🎫 **Ticket: ${ticket.title}**
--------------------------------------------------
- **Estado:** ${ticket.status.toUpperCase()}
- **Prioridad:** ${ticket.priority}
- **SLA Status:** ${slaStatus}
- **Deadline:** ${deadline.toLocaleString()}
--------------------------------------------------`;
}