﻿import { z } from "zod";
import { supabase } from "../lib/supabase.js";
import { classifyPriority } from "../lib/ai.js";

export const prioritizeIncidentSchema = z.object({
  id: z.string().uuid().describe("ID del ticket"),
  new_description: z.string().optional().describe("Nueva información para re-evaluar la prioridad")
});

export async function prioritizeIncident(args: { id: string, new_description?: string }) {
  const { data: ticket } = await supabase.from('tickets').select('*').eq('id', args.id).single();
  if (!ticket) return "❌ Ticket no encontrado.";

  // Fix: Re-evaluación con IA según README
  const analysis = await classifyPriority(
    ticket.title, 
    args.new_description || ticket.description
  );

  const { error } = await supabase
    .from('tickets')
    .update({ 
      priority: analysis.priority,
      ai_summary: `AI Re-evaluation: ${analysis.reasoning}`,
      updated_at: new Date().toISOString()
    })
    .eq('id', args.id);

  return error 
    ? "❌ Error al actualizar en Supabase." 
    : `✅ Incidente re-evaluado a ${analysis.priority}. Razón: ${analysis.reasoning}`;
}